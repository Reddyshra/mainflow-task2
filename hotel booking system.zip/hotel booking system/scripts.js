document.addEventListener('DOMContentLoaded', function() {
    const bookingForm = document.getElementById('bookingForm');
    const paymentForm = document.getElementById('paymentForm');

    if (bookingForm) {
        bookingForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const roomType = document.getElementById('roomType').value;
            const stayDuration = document.getElementById('stayDuration').value;
            localStorage.setItem('bookingDetails', JSON.stringify({ name, email, roomType, stayDuration }));
            location.href = 'payment.html';
        });
    }

    if (paymentForm) {
        paymentForm.addEventListener('submit', function(event) {
            event.preventDefault();
            location.href = 'confirmation.html';
        });
    }

    if (location.pathname.endsWith('confirmation.html')) {
        const bookingDetails = JSON.parse(localStorage.getItem('bookingDetails'));
        if (bookingDetails) {
            const { name, email, roomType, stayDuration } = bookingDetails;
            const confirmationMessage = `Thank you, ${name}! Your booking for a ${roomType} room for ${stayDuration} days has been confirmed. We have sent a confirmation email to ${email}.`;
            document.getElementById('confirmationMessage').innerText = confirmationMessage;
        }
    }
});
